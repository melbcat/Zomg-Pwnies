#include <sys/types.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <stdlib.h>
#include <fcntl.h>
#include <error.h>
#include <unistd.h>
#include <stdio.h>


#if __WORDSIZE != 32
#error This exercise is 32 bit. Try with -m32.
#endif


int main(int argc, char *argv[])
{
	int fd;
	struct stat sbuf;
	void (*shellcode)(void);
	int i;
	unsigned char *p;

	if (argc != 2) {
		fprintf(stderr, "Usage: %s shellcode-file\n", argv[0]);
		return EXIT_FAILURE;
	}

	if ((fd = open(argv[1], O_RDONLY)) < 0) {
		perror("open() failed");
		return EXIT_FAILURE;
	}

	if (fstat(fd, &sbuf)) {
		perror("fstat() failed");
		return EXIT_FAILURE;
	}

	if ((shellcode = mmap(NULL, sbuf.st_size,
			PROT_READ | PROT_WRITE | PROT_EXEC,
			MAP_PRIVATE, fd, 0)) == MAP_FAILED) {
		perror("mmap() failed");
		return EXIT_FAILURE;
	}

	close(fd);

	for (i=0, p=(void *)shellcode; i<sbuf.st_size; i++) {
		if (p[i] == '\0') {
			fprintf(stderr, "The shellcode contains"
					" NUL-bytes.\n");
			return EXIT_FAILURE;
		}
	}

	shellcode();

	/* should not be reached */
	return EXIT_FAILURE;
}
